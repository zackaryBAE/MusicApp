import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Mic, Play, Pause, Square, Trash2, Volume2, VolumeX, 
  Activity, Music, Zap, Settings, Layers, Download, Sliders
} from 'lucide-react';
import './App.css';

const App = () => {
  // State
  const [tracks, setTracks] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [tempo, setTempo] = useState(120);
  const [isMetronomeOn, setIsMetronomeOn] = useState(false);
  const [masterVolume, setMasterVolume] = useState(0.8);
  const [reverbAmount, setReverbAmount] = useState(0);
  const [delayAmount, setDelayAmount] = useState(0);
  const [filterFreq, setFilterFreq] = useState(20000); // Low-pass filter (20Hz - 20kHz)
  const [distortionAmount, setDistortionAmount] = useState(0);
  const [inputDevices, setInputDevices] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showDrums, setShowDrums] = useState(false); // Toggle Drum Pad
  
  // Audio Refs
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const canvasRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const sourceRef = useRef(null);
  const animationRef = useRef(null);
  const metronomeIntervalRef = useRef(null);
  
  // Effects Refs
  const masterGainRef = useRef(null);
  const filterNodeRef = useRef(null);
  const distortionNodeRef = useRef(null);
  const delayNodeRef = useRef(null);
  const delayGainRef = useRef(null);
  const reverbNodeRef = useRef(null);
  const reverbGainRef = useRef(null);
  const destinationRef = useRef(null); // For export

  useEffect(() => {
    // Initialize Audio Context
    audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = audioContextRef.current;
    
    // Master Gain
    masterGainRef.current = ctx.createGain();
    masterGainRef.current.gain.value = masterVolume;

    // Insert Effects (Series)
    // 1. Distortion (WaveShaper)
    distortionNodeRef.current = ctx.createWaveShaper();
    distortionNodeRef.current.curve = makeDistortionCurve(0);
    distortionNodeRef.current.oversample = '4x';

    // 2. Filter (BiquadFilter)
    filterNodeRef.current = ctx.createBiquadFilter();
    filterNodeRef.current.type = 'lowpass';
    filterNodeRef.current.frequency.value = 20000;

    // Analyser (Visualizer)
    analyserRef.current = ctx.createAnalyser();
    analyserRef.current.fftSize = 2048;

    // Effects Setup
    // Delay
    delayNodeRef.current = ctx.createDelay();
    delayNodeRef.current.delayTime.value = 0.4; // 400ms delay
    delayGainRef.current = ctx.createGain();
    delayGainRef.current.gain.value = 0; // Off by default

    // Reverb (Convolver) - Simulate simple impulse
    reverbNodeRef.current = ctx.createConvolver();
    // Create a simple impulse response for reverb
    const rate = ctx.sampleRate;
    const length = rate * 2; // 2 seconds
    const impulse = ctx.createBuffer(2, length, rate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);
    for (let i = 0; i < length; i++) {
      const decay = Math.pow(1 - i / length, 2); // Simple linear decay
      left[i] = (Math.random() * 2 - 1) * decay;
      right[i] = (Math.random() * 2 - 1) * decay;
    }
    reverbNodeRef.current.buffer = impulse;
    
    reverbGainRef.current = ctx.createGain();
    reverbGainRef.current.gain.value = 0;

    // Routing: Master -> Analyser -> Destination
    masterGainRef.current.connect(analyserRef.current);
    analyserRef.current.connect(ctx.destination);
    
    // Helper for distortion curve
    function makeDistortionCurve(amount) {
      const k = typeof amount === 'number' ? amount : 50;
      const n_samples = 44100;
      const curve = new Float32Array(n_samples);
      const deg = Math.PI / 180;
      for (let i = 0; i < n_samples; ++i) {
        const x = (i * 2) / n_samples - 1;
        curve[i] = (3 + k) * x * 20 * deg / (Math.PI + k * Math.abs(x));
      }
      return curve;
    }

    // Create a destination for export (MediaStreamDestination)
    destinationRef.current = ctx.createMediaStreamDestination();
    masterGainRef.current.connect(destinationRef.current);
    
    // Fetch Audio Devices
    const getDevices = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const inputs = devices.filter(d => d.kind === 'audioinput');
        setInputDevices(inputs);
        // Don't auto-select if one is already selected (persistence could be added here)
        if (inputs.length > 0 && !selectedDeviceId) {
           setSelectedDeviceId(inputs[0].deviceId);
        }
      } catch (err) {
        console.error("Error fetching devices:", err);
      }
    };
    getDevices();
    navigator.mediaDevices.addEventListener('devicechange', getDevices);

    return () => {
      if (audioContextRef.current) audioContextRef.current.close();
      cancelAnimationFrame(animationRef.current);
      if (metronomeIntervalRef.current) clearInterval(metronomeIntervalRef.current);
      navigator.mediaDevices.removeEventListener('devicechange', getDevices);
    };
  }, []);

  // Update Effects
  useEffect(() => {
    if (masterGainRef.current) masterGainRef.current.gain.value = masterVolume;
  }, [masterVolume]);

  useEffect(() => {
    if (reverbGainRef.current) reverbGainRef.current.gain.value = reverbAmount;
  }, [reverbAmount]);

  useEffect(() => {
    if (delayGainRef.current) delayGainRef.current.gain.value = delayAmount;
  }, [delayAmount]);
  
  useEffect(() => {
    if (filterNodeRef.current) {
      // Exponential ramp for smooth filter sweeps
      const currentTime = audioContextRef.current.currentTime;
      filterNodeRef.current.frequency.setTargetAtTime(filterFreq, currentTime, 0.1);
    }
  }, [filterFreq]);

  useEffect(() => {
    if (distortionNodeRef.current) {
      // Re-calculate curve when amount changes
      // Need to define makeDistortionCurve inside or outside. 
      // For simplicity, let's just use a simple lookup or helper if accessible.
      // Since makeDistortionCurve was defined in the mount effect, we need it here.
      // Let's move makeDistortionCurve to a helper outside component or useCallback.
      
      const makeDistortionCurve = (amount) => {
         const k = amount * 100; // Scale 0-1 to 0-100
         const n_samples = 44100;
         const curve = new Float32Array(n_samples);
         const deg = Math.PI / 180;
         for (let i = 0; i < n_samples; ++i) {
           const x = (i * 2) / n_samples - 1;
           curve[i] = (3 + k) * x * 20 * deg / (Math.PI + k * Math.abs(x));
         }
         return curve;
      };
      distortionNodeRef.current.curve = makeDistortionCurve(distortionAmount);
    }
  }, [distortionAmount]);

  // Drum Synthesis
  const playDrum = (type) => {
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') ctx.resume();
    
    const t = ctx.currentTime;
    
    if (type === 'kick') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(masterGainRef.current);
      
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(0.01, t + 0.5);
      
      gain.gain.setValueAtTime(1, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.5);
      
      osc.start(t);
      osc.stop(t + 0.5);
    } else if (type === 'snare') {
      const noiseBuffer = ctx.createBuffer(1, ctx.sampleRate * 0.2, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < noiseBuffer.length; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;
      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.value = 1000;
      const noiseGain = ctx.createGain();
      
      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(masterGainRef.current);
      
      noiseGain.gain.setValueAtTime(1, t);
      noiseGain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
      noise.start(t);
    } else if (type === 'hihat') {
      // Similar to snare but shorter and higher pitch
      const noiseBuffer = ctx.createBuffer(1, ctx.sampleRate * 0.05, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < noiseBuffer.length; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;
      const bandpass = ctx.createBiquadFilter();
      bandpass.type = 'bandpass';
      bandpass.frequency.value = 10000;
      const gain = ctx.createGain();
      
      noise.connect(bandpass);
      bandpass.connect(gain);
      gain.connect(masterGainRef.current);
      
      gain.gain.setValueAtTime(0.6, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.05);
      noise.start(t);
    }
  };

  // Metronome
  const toggleMetronome = useCallback(() => {
    if (isMetronomeOn) {
      clearInterval(metronomeIntervalRef.current);
      setIsMetronomeOn(false);
    } else {
      setIsMetronomeOn(true);
      const interval = (60 / tempo) * 1000;
      metronomeIntervalRef.current = setInterval(() => {
        const osc = audioContextRef.current.createOscillator();
        const gain = audioContextRef.current.createGain();
        osc.frequency.value = 1000;
        gain.gain.value = 0.1;
        osc.connect(gain);
        gain.connect(audioContextRef.current.destination);
        osc.start();
        osc.stop(audioContextRef.current.currentTime + 0.05);
      }, interval);
    }
  }, [isMetronomeOn, tempo]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.code === 'Space') {
        e.preventDefault(); // Prevent scrolling
        isPlaying ? stopAll() : playAll();
      }
      if (e.code === 'KeyR') {
        isRecording ? stopRecording() : startRecording();
      }
      
      // Drum Shortcuts
      if (!isRecording && showDrums) {
        if (e.code === 'KeyQ') playDrum('kick');
        if (e.code === 'KeyW') playDrum('snare');
        if (e.code === 'KeyE') playDrum('hihat');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isRecording]); // Dependencies for latest state


  // Visualizer Logic
  const drawVisualizer = () => {
    if (!canvasRef.current || !analyserRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const renderFrame = () => {
      animationRef.current = requestAnimationFrame(renderFrame);
      analyserRef.current.getByteFrequencyData(dataArray);

      ctx.fillStyle = 'rgba(9, 9, 11, 0.2)'; // Fade effect for trails
      ctx.fillRect(0, 0, width, height);

      const barWidth = (width / bufferLength) * 2.5;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * height * 0.8;
        
        // Dynamic gradient
        const gradient = ctx.createLinearGradient(0, height, 0, height - barHeight);
        gradient.addColorStop(0, '#8b5cf6');
        gradient.addColorStop(1, '#ec4899');
        
        ctx.fillStyle = gradient;
        
        // Rounded bars
        ctx.beginPath();
        ctx.roundRect(x, height - barHeight, barWidth, barHeight, 5);
        ctx.fill();

        x += barWidth + 2;
      }
    };

    renderFrame();
  };

  const startRecording = async () => {
    try {
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }

      const constraints = selectedDeviceId 
        ? { audio: { deviceId: { exact: selectedDeviceId } } } 
        : { audio: true };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      // Visualizer connection
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);
      sourceRef.current = source;

      // Recorder setup
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const url = URL.createObjectURL(audioBlob);
        
        const newTrack = {
          id: Date.now(),
          name: `Loop ${tracks.length + 1}`,
          url,
          isMuted: false,
          volume: 1.0,
          duration: 0 // Ideally calculate duration
        };
        
        setTracks(prev => [...prev, newTrack]);
        
        // Clean up stream
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      drawVisualizer();
      
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("Could not access microphone. Please ensure permissions are granted.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      // Stop visualizer source if needed, but let it fade
    }
  };

  const deleteTrack = (id) => {
    setTracks(tracks.filter(t => t.id !== id));
  };

  const toggleTrackMute = (id) => {
    setTracks(tracks.map(t => t.id === id ? { ...t, isMuted: !t.isMuted } : t));
  };

  // Improved Audio Playback with Web Audio API (for effects)
  const playTrackNode = (track) => {
    const audio = new Audio(track.url);
    const source = audioContextRef.current.createMediaElementSource(audio);
    
    // Connect to effects
    // Signal Flow: Source -> Distortion -> Filter -> [Split] -> (Dry) -> Master
    //                                              -> (Delay) -> Master
    //                                              -> (Reverb) -> Master
    
    // Connect Source to Insert Chain
    source.connect(distortionNodeRef.current);
    distortionNodeRef.current.connect(filterNodeRef.current);
    
    // Split from Filter output
    const filterOutput = filterNodeRef.current;
    
    // 1. Dry Signal
    filterOutput.connect(masterGainRef.current);
    
    // 2. Delay Send
    filterOutput.connect(delayNodeRef.current);
    delayNodeRef.current.connect(delayGainRef.current);
    delayGainRef.current.connect(masterGainRef.current);
    
    // 3. Reverb Send
    filterOutput.connect(reverbNodeRef.current);
    reverbNodeRef.current.connect(reverbGainRef.current);
    reverbGainRef.current.connect(masterGainRef.current);

    audio.loop = true;
    audio.play();
    return audio;
  };

  const [activeAudioElements, setActiveAudioElements] = useState([]);

  const playAll = () => {
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
    
    // Clear previous
    activeAudioElements.forEach(a => a.pause());
    
    const newAudioElements = tracks.map(track => {
      if (track.isMuted) return null;
      return playTrackNode(track);
    }).filter(Boolean);

    setActiveAudioElements(newAudioElements);
    setIsPlaying(true);
  };

  const stopAll = () => {
    activeAudioElements.forEach(audio => {
      audio.pause();
      audio.currentTime = 0;
    });
    setActiveAudioElements([]);
    setIsPlaying(false);
  };
  
  const exportMix = () => {
    if (tracks.length === 0) return;
    
    alert("Recording Mix... Please wait for loop duration (mock).");
    // In a real app, we'd render offline, but here we can record the output
    const dest = destinationRef.current;
    const recorder = new MediaRecorder(dest.stream);
    const chunks = [];
    
    recorder.ondataavailable = e => chunks.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'resonate-mix.webm';
      a.click();
    };
    
    recorder.start();
    
    // Play all tracks for one loop cycle (assuming similar length) or 10s
    playAll();
    
    setTimeout(() => {
      recorder.stop();
      stopAll();
    }, 5000); // Record for 5 seconds as demo
  };

  const handleImport = (e) => {
    const file = e.target.files[0];
    if (file) {
      const url = URL.createObjectURL(file);
      const newTrack = {
        id: Date.now(),
        name: file.name,
        url,
        isMuted: false,
        volume: 1.0,
        duration: 0
      };
      setTracks(prev => [...prev, newTrack]);
    }
  };

  return (
    <div className="app-container">
      {/* Settings Modal/Panel */}
      {showSettings && (
        <div className="settings-overlay" onClick={() => setShowSettings(false)}>
          <div className="settings-panel" onClick={e => e.stopPropagation()}>
             <h3>Audio Settings</h3>
             <div className="setting-item">
               <label>Input Device</label>
               <select 
                 value={selectedDeviceId} 
                 onChange={e => setSelectedDeviceId(e.target.value)}
                 className="device-select"
               >
                 {inputDevices.map(device => (
                   <option key={device.deviceId} value={device.deviceId}>
                     {device.label || `Microphone ${device.deviceId.slice(0,5)}...`}
                   </option>
                 ))}
                 {inputDevices.length === 0 && <option>Default Microphone</option>}
               </select>
             </div>

             <div className="setting-actions" style={{ display: 'flex', gap: 10, marginTop: 20 }}>
               <button 
                 onClick={() => {
                   const settings = { tempo, masterVolume, reverbAmount, delayAmount, filterFreq, distortionAmount };
                   localStorage.setItem('resonate_settings', JSON.stringify(settings));
                   alert('Settings Saved!');
                 }}
                 style={{ flex: 1, padding: 8, background: '#27272a', border: '1px solid #3f3f46', color: 'white', borderRadius: 6, cursor: 'pointer' }}
               >
                 Save Preset
               </button>
               <button 
                 onClick={() => {
                   const saved = localStorage.getItem('resonate_settings');
                   if (saved) {
                     const s = JSON.parse(saved);
                     if (s.tempo) setTempo(s.tempo);
                     if (s.masterVolume !== undefined) setMasterVolume(s.masterVolume);
                     if (s.reverbAmount !== undefined) setReverbAmount(s.reverbAmount);
                     if (s.delayAmount !== undefined) setDelayAmount(s.delayAmount);
                     if (s.filterFreq !== undefined) setFilterFreq(s.filterFreq);
                     if (s.distortionAmount !== undefined) setDistortionAmount(s.distortionAmount);
                     alert('Settings Loaded!');
                   } else {
                     alert('No saved settings found.');
                   }
                 }}
                 style={{ flex: 1, padding: 8, background: '#27272a', border: '1px solid #3f3f46', color: 'white', borderRadius: 6, cursor: 'pointer' }}
               >
                 Load Preset
               </button>
             </div>

             <button className="close-btn" onClick={() => setShowSettings(false)} style={{ marginTop: 20 }}>Done</button>
          </div>
        </div>
      )}

      <header>
        <div className="logo">
          <Music size={28} />
          RESONATE
        </div>
        <div className="user-profile">
          <button className="icon-btn" onClick={() => setShowSettings(!showSettings)}>
            <Settings size={24} color="#71717a" />
          </button>
        </div>
      </header>

      <div className="main-content">
        {/* Left Panel: Tracks */}
        <div className="tracks-panel">
          <div className="panel-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>
              <Layers size={14} style={{ marginRight: 8, display: 'inline-block' }} />
              Loop Station
            </span>
            <label className="import-btn" title="Import Audio">
              <input type="file" accept="audio/*" onChange={handleImport} hidden />
              + Import
            </label>
          </div>
          
          <div className="track-list">
            {tracks.length === 0 && (
              <div style={{ textAlign: 'center', padding: '20px', color: '#52525b', fontSize: '0.9rem' }}>
                No loops recorded yet.
                <br />Hit the mic to start.
              </div>
            )}
            {tracks.map(track => (
              <div key={track.id} className="track-item">
                <div className="track-header">
                  <span className="track-name">{track.name}</span>
                  <div className="track-controls">
                    <button 
                      className={`icon-btn ${track.isMuted ? 'active' : ''}`}
                      onClick={() => toggleTrackMute(track.id)}
                    >
                      {track.isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    </button>
                    <button 
                      className="icon-btn" 
                      onClick={() => deleteTrack(track.id)}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="panel-title" style={{ marginTop: '20px' }}>
            <Sliders size={14} style={{ marginRight: 8, display: 'inline-block' }} />
            Master Effects
          </div>
          <div className="effects-controls">
            <div className="effect-control">
              <label>Volume</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={masterVolume} 
                onChange={(e) => setMasterVolume(parseFloat(e.target.value))} 
              />
            </div>
            <div className="effect-control">
              <label>Filter (Low Pass)</label>
              <input 
                type="range" min="20" max="20000" step="10" 
                value={filterFreq} 
                onChange={(e) => setFilterFreq(parseFloat(e.target.value))} 
                title={filterFreq + "Hz"}
              />
            </div>
            <div className="effect-control">
              <label>Distortion</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={distortionAmount} 
                onChange={(e) => setDistortionAmount(parseFloat(e.target.value))} 
              />
            </div>
            <div className="effect-control">
              <label>Reverb</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={reverbAmount} 
                onChange={(e) => setReverbAmount(parseFloat(e.target.value))} 
              />
            </div>
            <div className="effect-control">
              <label>Delay (Echo)</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={delayAmount} 
                onChange={(e) => setDelayAmount(parseFloat(e.target.value))} 
              />
            </div>
          </div>
        </div>

        {/* Center: Visualizer */}
        <div className="visualizer-section">
          {isRecording && (
            <div className="recording-indicator">
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'currentColor' }} />
              RECORDING
            </div>
          )}
          
          {/* Drum Pad Toggle */}
          <button 
             className="drum-toggle-btn"
             onClick={() => setShowDrums(!showDrums)}
             style={{ position: 'absolute', top: 20, left: 20, zIndex: 5, background: 'rgba(255,255,255,0.1)', border: '1px solid #3f3f46', padding: '8px 12px', borderRadius: 20, color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}
          >
             <Music size={16} /> {showDrums ? 'Hide Drums' : 'Show Drums'}
          </button>
          
          {/* Drum Pad UI */}
          {showDrums && (
            <div className="drum-pad-container" style={{ position: 'absolute', bottom: 20, display: 'flex', gap: 12, zIndex: 5 }}>
               <button className="drum-pad" onClick={() => playDrum('kick')}>KICK (Q)</button>
               <button className="drum-pad" onClick={() => playDrum('snare')}>SNARE (W)</button>
               <button className="drum-pad" onClick={() => playDrum('hihat')}>HI-HAT (E)</button>
            </div>
          )}

          <canvas ref={canvasRef} width={800} height={400} />
          
          {!isRecording && tracks.length === 0 && (
             <div style={{ position: 'absolute', color: '#52525b', textAlign: 'center' }}>
                <h2>Ready to Create</h2>
                <p>Press <b>R</b> or Mic button to record.</p>
                <p style={{ fontSize: '0.8rem', marginTop: 10 }}>Space to Play/Pause</p>
             </div>
          )}
        </div>

        {/* Right Panel: AI Insights */}
        <div className="ai-panel">
          <div className="panel-title">
            <Zap size={14} style={{ marginRight: 8, display: 'inline-block' }} />
            AI Insights
          </div>

          <div className="ai-card">
            <div className="ai-stat">
              <div className="stat-label">Estimated Key</div>
              <div className="stat-value" style={{ color: '#8b5cf6' }}>C Minor</div>
            </div>
            <div className="ai-stat">
              <div className="stat-label">
                Tempo 
                <button 
                  onClick={toggleMetronome}
                  style={{ 
                    marginLeft: 10, background: 'none', border: 'none', 
                    color: isMetronomeOn ? '#ec4899' : '#52525b', cursor: 'pointer' 
                  }}
                >
                  <Activity size={14} />
                </button>
              </div>
              <div className="stat-value" style={{ color: '#ec4899' }}>{tempo} BPM</div>
              <input 
                type="range" min="60" max="180" 
                value={tempo} 
                onChange={(e) => setTempo(parseInt(e.target.value))}
                style={{ width: '100%', marginTop: 5 }}
              />
            </div>
            <div className="ai-stat">
              <div className="stat-label">Vibe</div>
              <div className="stat-value">Ethereal</div>
            </div>
          </div>

          <div className="suggestions">
            <div className="panel-title">Creative Suggestions</div>
            <ul className="suggestion-list">
              <li className="suggestion-item">
                <Activity size={16} color="#8b5cf6" />
                <span>Add a rhythmic bassline</span>
              </li>
              <li className="suggestion-item">
                <Activity size={16} color="#ec4899" />
                <span>Try a high-pass filter</span>
              </li>
              <li className="suggestion-item">
                <Activity size={16} color="#3b82f6" />
                <span>Harmonize with a 3rd up</span>
              </li>
            </ul>
          </div>

          <button className="btn-secondary" onClick={exportMix} style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 10, padding: 10, background: '#27272a', border: '1px solid #3f3f46', borderRadius: 8, color: 'white', cursor: 'pointer' }}>
             <Download size={16} /> Export Mix
          </button>
        </div>
      </div>

      <div className="main-controls">
        <button className="control-btn" onClick={stopAll} disabled={tracks.length === 0}>
          <Square size={20} fill="currentColor" />
        </button>

        <button 
          className={`control-btn primary ${isRecording ? 'recording' : ''}`}
          onClick={isRecording ? stopRecording : startRecording}
        >
          {isRecording ? <Square size={28} fill="currentColor" /> : <Mic size={28} />}
        </button>

        <button className="control-btn" onClick={playAll} disabled={tracks.length === 0}>
          {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" />}
        </button>
      </div>
    </div>
  );
};

export default App;
